키움 Open API + 를 이용한 시스템트레이딩

## 개발환경
 - Anaconda3-2.4.0 32bit (Python 3.5, PyQt4)
 - https://repo.continuum.io/archive/index.html

## 참고사이트
 - [파이썬을 이용한 시스템 트레이딩(기초편)](https://wikidocs.net/book/110)
