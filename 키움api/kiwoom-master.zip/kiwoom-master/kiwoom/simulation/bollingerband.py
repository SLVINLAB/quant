__author__ = 'sangchae'

# MA20 and 2*s.d
class BollingerBand:
    def __init__(self):
        pass