__author__ = 'sangchae'

# MA20 and +-20% from MA20
class Envelope:
    def __init__(self):
        pass