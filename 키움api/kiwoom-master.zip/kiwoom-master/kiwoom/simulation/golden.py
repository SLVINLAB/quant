__author__ = 'sangchae'

class GoldenCross:
    def __init__(self):
        pass