Check out your strategy based on Simulation
