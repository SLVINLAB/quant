"""
분할 매수
if the current price reaches the bottom line,
start to buy x % of total money for the item
"""

class accumulate:
    def __init__(self):
        print("분할매수")

    def abuy(self, ratio, totalamount):
        continue
