Please install BS4 with Python 3.4.4 as following link:

http://jhjeong.com/python/2016/01/28/beautifulsoup-web-crawling/
https://www.crummy.com/software/BeautifulSoup/bs4/doc/