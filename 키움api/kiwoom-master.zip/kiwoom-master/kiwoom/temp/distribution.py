"""
분할 매도
if it reaches the top line,
sell a half of the item
"""

class distribution:
    def __init__(self):
        print("분할매도")

    def asell(self, ratio, totalamount):
        continue
